
import React from 'react';
import { Message, Sender } from '../types';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.sender === Sender.User;
  const isAI = message.sender === Sender.AI;
  const isSystem = message.sender === Sender.System;

  if (isSystem) {
    return (
      <div className="bg-yellow-100 text-yellow-800 p-3 rounded-lg text-sm shadow-sm text-center font-khmer">
        {message.text.split('\n').map((line, i) => <p key={i}>{line}</p>)}
      </div>
    );
  }

  const senderName = isUser ? 'អ្នក' : 'AI';
  const avatarClass = isUser ? 'bg-indigo-500' : 'bg-blue-500';
  const bubbleClass = isUser 
    ? 'bg-indigo-500 text-white rounded-br-none' 
    : 'bg-gray-200 text-gray-800 rounded-bl-none';
  const alignmentClass = isUser ? 'justify-end' : 'justify-start';

  return (
    <div className={`flex items-start space-x-3 ${alignmentClass}`}>
      {!isUser && (
        <div className={`flex-shrink-0 w-8 h-8 rounded-full ${avatarClass} flex items-center justify-center text-white font-bold font-khmer`}>
          {senderName}
        </div>
      )}
      <div className={`p-3 rounded-lg shadow-sm max-w-xs md:max-w-md ${bubbleClass}`}>
        <p className="text-sm whitespace-pre-line font-khmer">{message.text}</p>
      </div>
       {isUser && (
        <div className={`flex-shrink-0 w-8 h-8 rounded-full ${avatarClass} flex items-center justify-center text-white font-bold`}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
          </svg>
        </div>
      )}
    </div>
  );
};

export default MessageBubble;
