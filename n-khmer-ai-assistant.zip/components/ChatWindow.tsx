
import React, { useState, useRef, useEffect } from 'react';
import { Message, Ad } from '../types';
import MessageBubble from './MessageBubble';
import AdMessage from './AdBanner';

interface ChatWindowProps {
  messages: Message[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  onAdClick: (ad: Ad) => void;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, onSendMessage, isLoading, onAdClick }) => {
  const [inputValue, setInputValue] = useState('');
  const chatAreaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatAreaRef.current) {
      chatAreaRef.current.scrollTop = chatAreaRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSendMessage(inputValue);
    setInputValue('');
  };

  return (
    <>
      <main ref={chatAreaRef} className="flex-1 p-4 space-y-4 overflow-y-auto chat-area bg-slate-50">
        {messages.map((msg) =>
          msg.ad ? (
            <AdMessage key={msg.id} ad={msg.ad} onAdClick={onAdClick} />
          ) : (
            <MessageBubble key={msg.id} message={msg} />
          )
        )}
        {isLoading && (
          <div className="flex items-start space-x-3">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold font-khmer">
              AI
            </div>
            <div className="bg-gray-200 p-3 rounded-lg rounded-tl-none shadow-sm max-w-xs md:max-w-md animate-pulse">
                <div className="h-4 bg-gray-300 rounded w-24"></div>
            </div>
          </div>
        )}
      </main>

      <form onSubmit={handleSubmit} className="p-2 border-t flex items-center bg-white">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          className="flex-1 p-3 rounded-full border bg-gray-100 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all text-black placeholder-black"
          placeholder="សរសេរសាររបស់អ្នក... (Type your message...)"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !inputValue.trim()}
          className="ml-2 w-12 h-12 flex items-center justify-center bg-blue-500 text-white rounded-full disabled:bg-gray-300 hover:bg-blue-600 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
            <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
          </svg>
        </button>
      </form>
    </>
  );
};

export default ChatWindow;
