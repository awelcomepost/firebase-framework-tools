
import React from 'react';
import { Ad } from '../types';

interface AdMessageProps {
  ad: Ad;
  onAdClick: (ad: Ad) => void;
}

const AdMessage: React.FC<AdMessageProps> = ({ ad, onAdClick }) => {
  return (
    <div className="flex items-start space-x-3 justify-start">
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold font-khmer">
            AI
        </div>
        <div className="p-0.5 rounded-lg shadow-sm bg-gray-200 max-w-xs md:max-w-md">
            <div className="bg-white rounded-lg p-3 border border-gray-200">
                <div className="text-xs text-gray-500 font-sans font-semibold">AD</div>
                <div className="my-2">
                     <img
                        src={ad.ImageURL}
                        alt={ad.Title}
                        className="w-full h-32 object-cover rounded-md bg-gray-200"
                        onError={(e) => { e.currentTarget.src = 'https://picsum.photos/300/150' }}
                     />
                </div>
                <div className="font-semibold text-sm font-khmer text-black" title={ad.Title}>
                    {ad.Title}
                </div>
                <div className="text-xs text-gray-600 mt-1 font-khmer" title={ad.Description}>
                    {ad.Description}
                </div>
                 { ad.Promotion &&
                    <div className="text-xs text-green-600 font-bold mt-1 font-khmer" title={ad.Promotion}>
                        {ad.Promotion}
                    </div>
                }
                <div className="flex justify-between items-center mt-3">
                     <button
                        onClick={() => onAdClick(ad)}
                        className="inline-block text-sm px-4 py-1.5 bg-yellow-400 text-black font-semibold rounded-md hover:bg-yellow-500 transition-colors shadow"
                    >
                        ទិញទីនេះ (Buy Here)
                    </button>
                    <div className="text-[10px] text-right text-gray-400 font-sans">Clicks: {ad.Clicks || 0}</div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default AdMessage;
