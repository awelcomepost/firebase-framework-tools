
import React, { useState, useEffect } from 'react';
import { Message, Ad, Sender } from './types';
import { getAIResponse } from './services/geminiService';
import { fetchAds, trackAdClick } from './services/adService';
import ChatWindow from './components/ChatWindow';

const AD_FREQUENCY = 2; // Show ad after every 2 user messages

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'initial-1',
      sender: Sender.System,
      text: 'សួស្តី! ចាប់ផ្តើមវាយអត្ថបទដើម្បីជជែកជាមួយ AI។\nWelcome! Start typing below to chat with the AI.',
    },
  ]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [ads, setAds] = useState<Ad[]>([]);
  const [userMessageCount, setUserMessageCount] = useState(0);
  const [adIndex, setAdIndex] = useState(0);


  useEffect(() => {
    const loadAds = async () => {
      const adsData = await fetchAds();
      if (adsData && adsData.length > 0) {
        setAds(adsData);
      }
    };
    loadAds();
  }, []);

  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      sender: Sender.User,
      text,
    };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    const newUserMessageCount = userMessageCount + 1;
    setUserMessageCount(newUserMessageCount);

    try {
      const aiText = await getAIResponse(text);
      const aiMessage: Message = {
        id: `ai-${Date.now()}`,
        sender: Sender.AI,
        text: aiText,
      };

      const messagesToAdd : Message[] = [aiMessage];

      // Check if it's time to show an ad
      if (ads.length > 0 && newUserMessageCount % AD_FREQUENCY === 0) {
        const adToShow = ads[adIndex];
        const adMessage: Message = {
            id: `ad-${Date.now()}`,
            sender: Sender.AI, // Ad comes from "AI"
            text: '', // No text content
            ad: adToShow,
        };
        messagesToAdd.push(adMessage);
        setAdIndex(prev => (prev + 1) % ads.length); // Cycle through ads
      }
      
      setMessages(prev => [...prev, ...messagesToAdd]);

    } catch (error) {
      console.error(error);
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        sender: Sender.AI,
        text: '❌ សូមអភ័យទោស មានបញ្ហាក្នុងការទាក់ទងជាមួយ AI។ (Sorry, there was an issue connecting to the AI.)',
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAdClick = async (ad: Ad) => {
    await trackAdClick(ad.Title);
     // Also update the ad in the message history for instant feedback
    setMessages(currentMessages => currentMessages.map(m => {
        if(m.ad && m.ad.Title === ad.Title) {
            const newClicks = (m.ad.Clicks || 0) + 1;
            return {...m, ad: {...m.ad, Clicks: newClicks}};
        }
        return m;
    }));
    window.open(ad.BuyLink, '_blank');
  };

  return (
    <div className="flex justify-center items-center h-screen">
      <div className="flex flex-col h-screen w-full max-w-md bg-white rounded-lg shadow-2xl overflow-hidden relative">
        <header className="bg-blue-600 text-white text-center py-3 shadow-md z-10">
          <h1 className="text-xl font-semibold font-khmer">AI ជំនួយការភាសាខ្មែរ</h1>
          <p className="text-xs opacity-80">Guest Mode (by: vanrot)</p>
        </header>
        <ChatWindow
          messages={messages}
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
          onAdClick={handleAdClick}
        />
      </div>
    </div>
  );
};

export default App;
