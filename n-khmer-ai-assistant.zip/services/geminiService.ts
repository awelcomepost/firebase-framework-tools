
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const systemInstruction = "You are a bilingual AI assistant. Always provide your response first in Khmer, followed by the English translation in parentheses. For example: សួស្តី (Hello). Be helpful and friendly. If the user asks a question in English, answer in English first, then provide the Khmer translation in parentheses.";

export const getAIResponse = async (userPrompt: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: userPrompt,
      config: {
        systemInstruction: systemInstruction,
      },
    });
    
    const text = response.text;
    
    if (!text) {
        return "សូមអភ័យទោស មិនអាចបង្កើតចម្លើយបានទេនៅពេលនេះ។ (Sorry, I was unable to generate a response at this time.)";
    }

    return text;
  } catch (error) {
    console.error("Error fetching from Gemini API:", error);
    throw new Error("Failed to get response from AI.");
  }
};
