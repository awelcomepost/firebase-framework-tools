
import { Ad } from '../types';

const ADS_API_URL = "https://script.google.com/macros/s/AKfycbxkatOWsnZXviyYziF6hNYYJht1fhmA9ZMMhF8SGNVUVAr7nhDfuX1CRhcG7xR4mp3g/exec";

export const fetchAds = async (): Promise<Ad[]> => {
  try {
    const response = await fetch(ADS_API_URL);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    if (data && Array.isArray(data.ads)) {
      return data.ads;
    }
    return [];
  } catch (error) {
    console.error("Failed to fetch ads:", error);
    return [];
  }
};

export const trackAdClick = async (title: string): Promise<void> => {
  try {
    await fetch(ADS_API_URL, {
      method: 'POST',
      // The API seems to want a specific content type, but standard is application/json
      // For compatibility with the example, we'll keep it simple.
      // A proper API might require 'Content-Type': 'application/json'
      // and body: JSON.stringify({ action: "click", title })
      // but the original code did not set Content-Type header on POST,
      // so we will mimic that behavior by sending a plain text body.
      // Let's correct this to modern standards.
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ action: 'click', title }),
      mode: 'no-cors', // To avoid CORS issues with Google Scripts when sending POST from a different origin. The request will be opaque.
    });
  } catch (error) {
    console.error("Failed to track ad click:", error);
  }
};
