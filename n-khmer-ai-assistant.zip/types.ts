
export enum Sender {
  User = "User",
  AI = "AI",
  System = "System",
}

export interface Message {
  id: string;
  sender: Sender;
  text: string;
  ad?: Ad;
}

export interface Ad {
  ImageURL: string;
  Title: string;
  Description: string;
  Promotion: string;
  BuyLink: string;
  Clicks: number;
}
